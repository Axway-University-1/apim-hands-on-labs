curl --location -k --request POST 'https://server1:18075/api/portal/v1.4/currentuser/changepassword' --header 'Authorization: Basic YXBpYWRtaW46QXh3YXkxMjM=' --header 'Content-Type: application/x-www-form-urlencoded' --data-urlencode 'oldPassword=Axway123' --data-urlencode 'newPassword=Axway456'    
     

