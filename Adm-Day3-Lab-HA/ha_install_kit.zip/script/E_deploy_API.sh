echo "/////////////////////////////////////////////////////////////"
echo "// Deploy API"
echo "/////////////////////////////////////////////////////////////"
curl -k -u "apiadmin:Axway456" --header "Content-Type: application/json" --request POST --data '{"enabled":true,"development":true,"name":"API Development","email":"","phone":"","description":"","virtualHost":""}' https://server1:18075/api/portal/v1.3/organizations/

$SERVER1/apigateway/posix/bin/apimanager-promote --target https://server1:18075 --username apiadmin --password Axway456 $CONF_FOLDER
