echo "/////////////////////////////////////////////////////////////"
echo "// Install the 2 API Manager nodes, declare NM and create group and instances"
echo "/////////////////////////////////////////////////////////////"

$APIGTW_INSTALL --debuglevel 0 --mode unattended  --setup_type advanced --enable-components apigateway,apimgmt --disable-components qstart,policystudio,configurationstudio,packagedeploytools,cassandra,analytics --nmPort 18090 --firstInNewDomain 0 --prefix $SERVER1 --changeCredentials 1 --username admin --adminpasswd Axway123 --licenseFilePath $APIGTW_LICENCE --apimgmtLicenseFilePath $APIGTW_LICENCE

$SERVER1/apigateway/posix/bin/managedomain --add  --anm_host server3 --anm_port 38090 --host server1 --port 18090 --nm_name NM1 --username admin --password Axway123 --sign_with_user_provided --ca $CERT_FOLDER/APIM_Domain_CA.p12 --sign_alg sha256 --domain_passphrase Axway123 --key_passphrase Axway123

$SERVER1/apigateway/posix/bin/nodemanager -d

$SERVER1/apigateway/posix/bin/managedomain --create_instance --anm_host server3 --anm_port 38090 --name myinstance-server1 --group mygroup -s 18080 -m 18085 --username admin --password Axway123 --sign_with_user_provided  --ca $CERT_FOLDER/APIM_Domain_CA.p12 --sign_alg sha256 --domain_passphrase Axway123 --key_passphrase Axway123
sleep 5
cp $CONF_FOLDER/envSettings_server1.props $SERVER1/apigateway/groups/topologylinks/mygroup-myinstance-server1/conf/envSettings.props
$SERVER1/apigateway/posix/bin/startinstance -g "mygroup" -n "myinstance-server1" -d


$APIGTW_INSTALL --debuglevel 0 --mode unattended  --setup_type advanced --enable-components apigateway,apimgmt --disable-components qstart,policystudio,configurationstudio,packagedeploytools,cassandra,analytics --nmPort 28090 --firstInNewDomain 0 --prefix $SERVER2 --changeCredentials 1 --username admin --adminpasswd Axway123 --licenseFilePath $APIGTW_LICENCE --apimgmtLicenseFilePath $APIGTW_LICENCE

$SERVER2/apigateway/posix/bin/managedomain --add  --anm_host server3 --anm_port 38090 --host server2 --port 28090 --nm_name NM2 --username admin --password Axway123 --sign_with_user_provided --ca $CERT_FOLDER/APIM_Domain_CA.p12 --sign_alg sha256 --domain_passphrase Axway123 --key_passphrase Axway123

$SERVER2/apigateway/posix/bin/nodemanager -d

$SERVER2/apigateway/posix/bin/managedomain --create_instance  --anm_host server3 --anm_port 38090 --name myinstance-server2 --group mygroup -s 28080 -m 28085 --username admin --password Axway123 --sign_with_user_provided  --ca $CERT_FOLDER/APIM_Domain_CA.p12 --sign_alg sha256 --domain_passphrase Axway123 --key_passphrase Axway123
sleep 5
cp $CONF_FOLDER/envSettings_server2.props $SERVER2/apigateway/groups/topologylinks/mygroup-myinstance-server2/conf/envSettings.props
$SERVER2/apigateway/posix/bin/startinstance -g "mygroup" -n "myinstance-server2" -d


echo
echo "/////////////////////////////////////////////////////////////"
echo "// Deploy Policy"
echo "/////////////////////////////////////////////////////////////"
$SERVER1/apigateway/posix/bin/managedomain --deploy --anm_host server3 --anm_port 38090 --username admin --password Axway123 --group mygroup --policy_archive_filename $POLICY_POL --env_archive_filename $POLICY_ENV


