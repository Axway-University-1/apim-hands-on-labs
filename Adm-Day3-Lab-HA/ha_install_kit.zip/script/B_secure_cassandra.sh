if [ -z $HA_HOME ]; then
	echo Please load ha_profile.sh
	exit 1
fi

wait_host_port(){
        while ! nc -z $1 $2; do
                sleep 1
        done
}


echo "/////////////////////////////////////////////////////////////"
echo "// Secure Cassandra installation"
echo "/////////////////////////////////////////////////////////////"
echo
echo NODE-TO-NODE ENCRYPTION
echo =======================
$SERVER3/apigateway/platform/jre/bin/keytool -keystore $SERVER3/cassandra/conf/server-truststore.jks -importcert -file $CERT_FOLDER/server-ca.pem -storepass Axway123 -noprompt
$SERVER3/apigateway/platform/jre/bin/keytool -importkeystore -deststorepass Axway123 -destkeypass Axway123 -destkeystore $SERVER3/cassandra/conf/server-keystore.jks -srckeystore $CERT_FOLDER/APIM_Cassandra_Server3.p12 -srcstoretype PKCS12 <<< Axway123
$SERVER3/apigateway/platform/jre/bin/keytool -keystore $SERVER3/cassandra/conf/server-keystore.jks -importcert -file $CERT_FOLDER/server-ca.pem -storepass Axway123 -noprompt

$SERVER4/apigateway/platform/jre/bin/keytool -keystore $SERVER4/cassandra/conf/server-truststore.jks -importcert -file $CERT_FOLDER/server-ca.pem -storepass Axway123 -noprompt
$SERVER4/apigateway/platform/jre/bin/keytool -importkeystore -deststorepass Axway123 -destkeypass Axway123 -destkeystore $SERVER4/cassandra/conf/server-keystore.jks -srckeystore $CERT_FOLDER/APIM_Cassandra_Server4.p12 -srcstoretype PKCS12 <<< Axway123
$SERVER4/apigateway/platform/jre/bin/keytool -keystore $SERVER4/cassandra/conf/server-keystore.jks -importcert -file $CERT_FOLDER/server-ca.pem -storepass Axway123 -noprompt

$SERVER5/apigateway/platform/jre/bin/keytool -keystore $SERVER5/cassandra/conf/server-truststore.jks -importcert -file $CERT_FOLDER/server-ca.pem -storepass Axway123 -noprompt
$SERVER5/apigateway/platform/jre/bin/keytool -importkeystore -deststorepass Axway123 -destkeypass Axway123 -destkeystore $SERVER5/cassandra/conf/server-keystore.jks -srckeystore $CERT_FOLDER/APIM_Cassandra_Server5.p12 -srcstoretype PKCS12 <<< Axway123
$SERVER5/apigateway/platform/jre/bin/keytool -keystore $SERVER5/cassandra/conf/server-keystore.jks -importcert -file $CERT_FOLDER/server-ca.pem -storepass Axway123 -noprompt


echo 
echo CLIENT-TO-NODE ENCRYPTION
echo =========================
$SERVER3/apigateway/platform/jre/bin/keytool -keystore $SERVER3/cassandra/conf/client-truststore.jks -importcert -file $CERT_FOLDER/client-ca.pem -storepass Axway123 -noprompt
$SERVER3/apigateway/platform/jre/bin/keytool -importkeystore -deststorepass Axway123 -destkeypass Axway123 -destkeystore $SERVER3/cassandra/conf/client-keystore.jks -srckeystore $CERT_FOLDER/APIM_Cassandra_Server3.p12 -srcstoretype PKCS12 <<< Axway123
$SERVER3/apigateway/platform/jre/bin/keytool -keystore $SERVER3/cassandra/conf/client-keystore.jks -importcert -file $CERT_FOLDER/client-ca.pem -storepass Axway123 -noprompt

$SERVER4/apigateway/platform/jre/bin/keytool -keystore $SERVER4/cassandra/conf/client-truststore.jks -importcert -file $CERT_FOLDER/client-ca.pem -storepass Axway123 -noprompt
$SERVER4/apigateway/platform/jre/bin/keytool -importkeystore -deststorepass Axway123 -destkeypass Axway123 -destkeystore $SERVER4/cassandra/conf/client-keystore.jks -srckeystore $CERT_FOLDER/APIM_Cassandra_Server4.p12 -srcstoretype PKCS12 <<< Axway123
$SERVER4/apigateway/platform/jre/bin/keytool -keystore $SERVER4/cassandra/conf/client-keystore.jks -importcert -file $CERT_FOLDER/client-ca.pem -storepass Axway123 -noprompt

$SERVER5/apigateway/platform/jre/bin/keytool -keystore $SERVER5/cassandra/conf/client-truststore.jks -importcert -file $CERT_FOLDER/client-ca.pem -storepass Axway123 -noprompt
$SERVER5/apigateway/platform/jre/bin/keytool -importkeystore -deststorepass Axway123 -destkeypass Axway123 -destkeystore $SERVER5/cassandra/conf/client-keystore.jks -srckeystore $CERT_FOLDER/APIM_Cassandra_Server5.p12 -srcstoretype PKCS12 <<< Axway123
$SERVER5/apigateway/platform/jre/bin/keytool -keystore $SERVER5/cassandra/conf/client-keystore.jks -importcert -file $CERT_FOLDER/client-ca.pem -storepass Axway123 -noprompt

echo
echo START CASSANDRA
echo ===============
nohup $SERVER3/cassandra/bin/cassandra > $SERVER3/cassandra/nohup.out 2>&1
wait_host_port server3 9160
# sleep 60
echo Cassandra node 1 started
nohup $SERVER4/cassandra/bin/cassandra > $SERVER4/cassandra/nohup.out 2>&1
wait_host_port server4 9160
# sleep 60
echo Cassandra node 2 started
nohup $SERVER5/cassandra/bin/cassandra > $SERVER5/cassandra/nohup.out 2>&1
wait_host_port server5 9160
# sleep 60
echo Cassandra node 3 started

echo
echo RESET DEFAULT USERNAME AND PASSWORD
echo ===================================
$SERVER3/cassandra/bin/cqlsh --cqlshrc=$CONF_FOLDER/cqlshrc --ssl -u cassandra -p cassandra -e "CREATE ROLE admin WITH PASSWORD = 'Axway123' AND SUPERUSER = true AND LOGIN = true" server3 9042
$SERVER3/cassandra/bin/cqlsh --cqlshrc=$CONF_FOLDER/cqlshrc --ssl -u admin -p Axway123 -e "ALTER ROLE cassandra WITH PASSWORD = 'T8APQOi2hH9k5NHxHeKhXUUXdj5HGxfHmlKH2lX4zZNTxjlyuDMW' AND SUPERUSER = false" server3 9042

echo
echo UPDATING KEYSPACE REPLICATION 
echo =============================
echo $SERVER3/cassandra/bin/cqlsh --cqlshrc=$CONF_FOLDER/cqlshrc --ssl -u admin -p Axway123 server3 9042
$SERVER3/cassandra/bin/cqlsh --cqlshrc=$CONF_FOLDER/cqlshrc --ssl -u admin -p Axway123 -e "ALTER KEYSPACE \"system_auth\" WITH REPLICATION = { 'class': 'SimpleStrategy', 'replication_factor': 3 }" server3 9042
$SERVER3/cassandra/bin/nodetool repair system_auth

echo
echo STOP AND RESTART CASSANDRA 
echo =============================
netstat -anp 2> /dev/null | grep "^tcp.*:.*9160.*LISTEN.*java" | grep -Po '\d+/java' | cut -d "/" -f 1 | xargs kill 
echo All Cassandra nodes stopped

nohup $SERVER3/cassandra/bin/cassandra > $SERVER3/cassandra/nohup.out 2>&1
wait_host_port server3 9160
# sleep 60
echo Cassandra node 1 started

nohup $SERVER4/cassandra/bin/cassandra > $SERVER4/cassandra/nohup.out 2>&1
wait_host_port server4 9160
# sleep 60
echo Cassandra node 2 started

nohup $SERVER5/cassandra/bin/cassandra > $SERVER5/cassandra/nohup.out 2>&1
wait_host_port server5 9160
# sleep 60
echo Cassandra node 3 started

ps -aux | grep cassandra | cut -c 1-128
