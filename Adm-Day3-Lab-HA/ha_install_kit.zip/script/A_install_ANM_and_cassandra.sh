if [ -z $HA_HOME ]; then
	echo Please load ha_profile.sh
	exit 1
fi

wait_host_port(){
        while ! nc -z $1 $2; do
                sleep 1
        done
}

echo "/////////////////////////////////////////////////////////////"
echo "// Install first ANM + Cassandra node"
echo "/////////////////////////////////////////////////////////////"
$APIGTW_INSTALL --debuglevel 0 --mode unattended  --setup_type advanced --enable-components apigateway,cassandra --disable-components analytics,qstart,policystudio,configurationstudio,apimgmt,packagedeploytools --nmPort 38090 --firstInNewDomain 1 --prefix $SERVER3 --cassandraInstalldir $SERVER3 --cassandraJDK $SERVER3/apigateway/platform/jre  --changeCredentials 1 --username admin --adminpasswd Axway123


echo "/////////////////////////////////////////////////////////////"
echo "//  Initialize Domain and start it"
echo "/////////////////////////////////////////////////////////////"
$SERVER3/apigateway/posix/bin/managedomain --initialize --host server3 --port 38090 --nm_name ANM1 --domain_name Domain --username admin --password Axway123 --sign_with_user_provided --ca $CERT_FOLDER/APIM_Domain_CA.p12 --sign_alg sha256 --domain_passphrase Axway123 --key_passphrase Axway123

$SERVER3/apigateway/posix/bin/nodemanager -d


echo "/////////////////////////////////////////////////////////////"
echo "// Initialize first Cassandra node and start it"
echo "/////////////////////////////////////////////////////////////"
$SERVER3/apigateway/posix/bin/setup-cassandra --seed --own-ip server3 --cassandra-config $SERVER3/cassandra/conf/cassandra.yaml --nodes=3 --enable-server-encryption --enable-client-encryption > $SERVER3/setup-cassandra-server3.out

cp $CONF_FOLDER/cassandra_secured_server3.yaml $SERVER3/cassandra/conf/cassandra.yaml
cp $CONF_FOLDER/cassandra-env_server3.sh $SERVER3/cassandra/conf/cassandra-env.sh
chmod 755 $SERVER3/cassandra/conf/cassandra-env.sh


echo "/////////////////////////////////////////////////////////////"
echo "// Install and configure ANM + Cassandra 2 and 3"
echo "/////////////////////////////////////////////////////////////"
$APIGTW_INSTALL --debuglevel 0 --mode unattended  --setup_type advanced --enable-components apigateway,cassandra --disable-components analytics,qstart,policystudio,configurationstudio,apimgmt,packagedeploytools --nmPort 48090 --firstInNewDomain 0 --prefix $SERVER4 --cassandraInstalldir $SERVER4 --cassandraJDK $SERVER4/apigateway/platform/jre  --changeCredentials 1 --username admin --adminpasswd Axway123

$SERVER4/apigateway/posix/bin/managedomain --add  --anm_host server3 --anm_port 38090 --host server4 --port 48090 --nm_name ANM2 --is_admin --username admin --password Axway123 --sign_with_user_provided --ca $CERT_FOLDER/APIM_Domain_CA.p12 --sign_alg sha256 --domain_passphrase Axway123 --key_passphrase Axway123

$SERVER4/apigateway/posix/bin/nodemanager -d

$SERVER4/apigateway/posix/bin/setup-cassandra --seed-ip server3 --own-ip server4 --cassandra-config $SERVER4/cassandra/conf/cassandra.yaml --nodes=3 --enable-server-encryption --enable-client-encryption > $SERVER4/setup-cassandra-server4.out

cp $CONF_FOLDER/cassandra_secured_server4.yaml $SERVER4/cassandra/conf/cassandra.yaml
cp $CONF_FOLDER/cassandra-env_server4.sh $SERVER4/cassandra/conf/cassandra-env.sh
chmod 755 $SERVER4/cassandra/conf/cassandra-env.sh

$APIGTW_INSTALL --debuglevel 0 --mode unattended  --setup_type advanced --enable-components apigateway,cassandra --disable-components analytics,qstart,policystudio,configurationstudio,apimgmt,packagedeploytools --nmPort 58090 --firstInNewDomain 0 --prefix $SERVER5 --cassandraInstalldir $SERVER5 --cassandraJDK $SERVER5/apigateway/platform/jre  --changeCredentials 1 --username admin --adminpasswd Axway123

$SERVER5/apigateway/posix/bin/managedomain --add  --anm_host server3 --anm_port 38090 --host server5 --port 58090 --nm_name ANM3 --is_admin --username admin --password Axway123 --sign_with_user_provided --ca $CERT_FOLDER/APIM_Domain_CA.p12 --sign_alg sha256 --domain_passphrase Axway123 --key_passphrase Axway123

$SERVER5/apigateway/posix/bin/nodemanager -d

$SERVER5/apigateway/posix/bin/setup-cassandra --seed-ip server3 --own-ip SERVER5 --cassandra-config $SERVER5/cassandra/conf/cassandra.yaml --nodes=3 --enable-server-encryption --enable-client-encryption > $SERVER5/setup-cassandra-server5.out

cp $CONF_FOLDER/cassandra_secured_server5.yaml $SERVER5/cassandra/conf/cassandra.yaml
cp $CONF_FOLDER/cassandra-env_server5.sh $SERVER5/cassandra/conf/cassandra-env.sh
chmod 755 $SERVER5/cassandra/conf/cassandra-env.sh

ps -aux | grep vshell

find $HA_HOME -name bin | grep apigateway/posix

find $HA_HOME -name cassandra | grep bin