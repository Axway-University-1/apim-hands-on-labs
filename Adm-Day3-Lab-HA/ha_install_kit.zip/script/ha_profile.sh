export CASSANDRA_HOME=
export HA_HOME=/home/axway/install/ha
export CERT_FOLDER=/home/axway/install/cert
export CONF_FOLDER=/home/axway/install/conf
export SCRIPT_FOLDER=/home/axway/install/script
export SERVER1=$HA_HOME/server1
export SERVER2=$HA_HOME/server2
export SERVER3=$HA_HOME/server3
export SERVER4=$HA_HOME/server4
export SERVER5=$HA_HOME/server5
mkdir -p $HA_HOME
mkdir -p $SERVER1
mkdir -p $SERVER2
mkdir -p $SERVER3
mkdir -p $SERVER4
mkdir -p $SERVER5
export APIGTW_INSTALL=/home/axway/Desktop/APIGateway_7.7.20210830_Install_linux-x86-64_BN02.run
export APIGTW_LICENCE=/usr/local/readytech/Inbox/API_7_7_Temp.lic
export POLICY_POL=/home/axway/install/conf/myproject.pol
export POLICY_ENV=/home/axway/install/conf/myproject.env

echo HA installation profile loaded
