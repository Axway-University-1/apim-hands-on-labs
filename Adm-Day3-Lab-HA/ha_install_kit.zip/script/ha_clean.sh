echo "/////////////////////////////////////////////////////////////"
echo "// Stop all processes by kill "
echo "/////////////////////////////////////////////////////////////"
netstat -anp 2> /dev/null | grep "^tcp.*:.*9160.*LISTEN.*java" | grep -Po '\d+/java' | cut -d "/" -f 1 | xargs kill -9
netstat -anp 2> /dev/null | grep "^tcp.*:.*8090.*LISTEN.*" | grep -Po '\d+/A?NM' | cut -d "/" -f 1 | xargs kill -9
netstat -anp 2> /dev/null | grep "^tcp.*:.*8080.*LISTEN.*" | grep -Po '\d+/' | cut -d "/" -f 1 | xargs kill -9
echo All APIM killed
echo
echo "/////////////////////////////////////////////////////////////"
echo "// Delete whole HA installation "
echo "/////////////////////////////////////////////////////////////"
rm -rf /home/axway/install/ha
echo HA installation deleted
echo
